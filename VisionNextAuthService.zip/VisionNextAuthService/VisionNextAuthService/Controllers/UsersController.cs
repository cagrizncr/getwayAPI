﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VisionNextAuthService.Entities;
using VisionNextAuthService.Helpers;
using VisionNextAuthService.Services;

namespace VisionNextAuthService.Controllers
{
    //[Authorize]
    [ApiController]
    [Route("api/[controller]")] 
    public class UsersController : ControllerBase 
    {
        private IUserService _userService;
        IConfiguration _configuration; 

        public UsersController(IUserService userService , IConfiguration configuration)
        {
            _userService = userService;
            _configuration = configuration;
        }

        [AllowAnonymous] 
        [HttpPost("Login")]  
        public IActionResult Login(string userName, string password) 
        {
            TokenHandler._configuration = _configuration;
            return Ok(userName == "gncy" && password == "12345" ? TokenHandler.CreateAccessToken(userName) : new UnauthorizedResult());
        }

        [AllowAnonymous]
        [HttpPost("Authenticate")] 
        public IActionResult Authenticate([FromBody] User userParam)
        {
            // throw new Exception("No entered!");

            var user = _userService.Authenticate(userParam.KullaniciAdi, userParam.Sifre);

            if (user == null)
                return BadRequest(new { message = "Kullanici veya şifre hatalı!" });

            return Ok(user);
        }

        [AllowAnonymous]
        [HttpGet("GetAll")]
        public IActionResult GetAll()
        {
            var users = _userService.GetAll();
            return Ok(users);
        }


        [AllowAnonymous]
        [HttpPost("register")]
        public IActionResult Register(User user)
        {
            bool isUserExist;
            isUserExist = _userService.IsUserExist(user);

            if (isUserExist)
                return BadRequest("Kullanıcı adı sistemde kayıtlıdır.");

            var users = _userService.Insert(user);
            return Ok(users);
        }
    }
}
